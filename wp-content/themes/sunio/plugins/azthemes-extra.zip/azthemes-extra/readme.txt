=== AzThemes Extra ===
Contributors: azthemes
Tags: widgets, meta box, metaboxes, metabox, azthemes

== Description ==

AzThemes Extra add extra features to [AzThemes](https://azthemes.net/) like widgets, metaboxes, activate/deactivate the customizer sections, enable/disable the theme's scripts and styles
This plugin requires the [AzThemes](https://azthemes.net/) theme to be installed.

== Installation ==

1. Upload `azthemes-extra` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Frequently Asked Questions ==

= I installed the plugin but it does not work =

This plugin will only work with the [AzThemes](https://azthemes.net/) theme.

== Screenshots ==

1. The meta boxes.
2. Customizer panels.
3. Custom CSS.
